from django.shortcuts import render , HttpResponse
from .models import Work

# Create your views here.
def home_page(request):
    articles = Work.objects.all().order_by('slug')
    return render(request,'home.html', {'articles':articles})



def contact(request):
    return render(request,'contact.html')



def article_detail(request,slug):
    # return HttpResponse(slug)
    article = Work.objects.get(slug=slug)
    return render(request, "page_of_work.html", {"article": article})
