from django.contrib import admin
from .models import Work

admin.site.register(Work)